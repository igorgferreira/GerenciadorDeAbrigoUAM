package br.uam.abrigos;
public class Alimento extends Produto {
    private String marca;
    private String validade;
    private float peso;
    private boolean refrigerado;
    private String pesoString = Float.toString(peso);
    //Construtor
    public Alimento(){}
    public Alimento(String nome, String lugar, float peso, boolean refrigerado, String marca, String validade) {
        super(nome, lugar);
        this.marca = marca;
        this.validade = validade;
        this.peso = peso;
        this.refrigerado = refrigerado;
    }
    //Getters & Setters
    public float getPeso() {
        return peso;
    }
    public void setPeso(float peso) {
        this.peso = peso;
    }
    public boolean isRefrigerado() {
        return refrigerado;
    }
    public void setRefrigerado(boolean refrigerado) {
        this.refrigerado = refrigerado;
    }
    public String getMarca() {
        return marca;
    }
    public void setMarca(String marca) {
        this.marca = marca;
    }
    public String getValidade() {
        return validade;
    }
    public void setValidade(String validade) {
        this.validade = validade;
    }
    //Print 
    @Override
    public void print(){
        System.out.println(getId());
        System.out.println(getNome());
        System.out.println(getLugar());
        System.out.println(getPeso());
        System.out.println(isRefrigerado());
        System.out.println(getValidade());
        System.out.println(getMarca());
    }
     public String getStrings(){
         return validade;
         
         
     }
    //Edit 
    @Override
    public void edit(String atributo, String novoValor){
        switch (atributo.toLowerCase()){
            case "marca":
                setMarca(novoValor);
                break;
            case "validade":
                setValidade(novoValor);
                break;
            case "nome":
                setNome(novoValor);
                break;
            case "lugar":
                setLugar(novoValor);
            case "peso":
                setPeso(Float.parseFloat(novoValor));
                break;
            case "refrigerado":
                setRefrigerado(Boolean.getBoolean(novoValor));
                break;
            default:
                System.out.println("Atributo inválido");
        }
    }
}

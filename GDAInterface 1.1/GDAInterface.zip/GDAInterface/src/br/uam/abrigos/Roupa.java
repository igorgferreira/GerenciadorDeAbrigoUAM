package br.uam.abrigos;
    
public class Roupa extends Produto{
    private String tamanho;
    private String obs;
    //Construtor
    public Roupa (){}
    public Roupa (String nome, String lugar, String tamanho, String obs){
        super(nome, lugar);
        this.tamanho = tamanho;
        this.obs = obs;
    }
    //Getters & Setters
    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }
    public String getObs(){
        return obs;
    }
    public void setObs(String obs){
        this.obs = obs;
    }
    //Print
    @Override
    public void print(){
        System.out.println(getId());
        System.out.println(getNome());
        System.out.println(getLugar());
        System.out.println(getTamanho());
        System.out.println(getObs());
    }
    //Edit
    @Override
    public void edit(String atributo,String novoValor){
        switch(atributo.toLowerCase()){
            case "tamanho":
                setTamanho(novoValor);
                break;
            case "obs":
                setObs(novoValor);
                break;
            case "nome":
                setNome(novoValor);
                break;
            case "lugar":
                setLugar(novoValor);
            default:
                System.out.println("Atributo inválido");
        }
    }
}
    
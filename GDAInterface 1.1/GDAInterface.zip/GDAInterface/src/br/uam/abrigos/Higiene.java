package br.uam.abrigos;
 public class Higiene extends Produto {
    private String marca;
    private String validade;
    private float peso;
    //Construtor
    public Higiene(){}
    public Higiene(String nome, String lugar, float peso, String marca, String validade) {
        super(nome, lugar);
        this.marca = marca;
        this.validade = validade;
        this.peso = peso;
        
    }
    //Getters & Setters
    public float getPeso() {
        return peso;
    }
    public void setPeso(float peso) {
        this.peso = peso;
    }
    public String getMarca() {
        return marca;
    }
    public void setMarca(String marca) {
        this.marca = marca;
    }
    public String getValidade() {
        return validade;
    }
    public void setValidade(String validade) {
        this.validade = validade;
    }
    //Print 
    @Override
    public void print(){
        System.out.println(getId());
        System.out.println(getNome());
        System.out.println(getLugar());
        System.out.println(getPeso());
        
        System.out.println(getValidade());
        System.out.println(getMarca());
    }
    //Edit 
    @Override
    public void edit(String atributo, String novoValor){
        switch (atributo.toLowerCase()){
            case "marca":
                setMarca(novoValor);
                break;
            case "validade":
                setValidade(novoValor);
                break;
            case "nome":
                setNome(novoValor);
                break;
            case "lugar":
                setLugar(novoValor);
            case "peso":
                setPeso(Float.parseFloat(novoValor));
                break;
            
            default:
                System.out.println("Atributo inválido");
        }
    }
 }